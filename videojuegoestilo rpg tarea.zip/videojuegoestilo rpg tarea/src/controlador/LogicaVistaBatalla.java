package controlador;

import modelo.EstadoJuego;
import modelo.EstadoJuego.EstadoBatalla;
import vista.VentanaPrincipal;
import vista.Lienzo;

import javax.swing.*;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;


public class LogicaVistaBatalla implements ActionListener {

    private final VentanaPrincipal ventana;
    private final EstadoJuego      estadoJuego;
    private final Lienzo           lienzo;
    private final Random           aleatorio = new Random();
    private Timer temporizadorRender;
    private Timer temporizadorEnemigo;
    private int fotogramasSacudida = 0;
    public LogicaVistaBatalla(VentanaPrincipal ventana, EstadoJuego estadoJuego) {
        this.ventana     = ventana;
        this.estadoJuego = estadoJuego;
        this.lienzo      = ventana.pn_lienzo;
        conectarBotones();
        iniciarBucleRender();
        estadoJuego.estado = EstadoBatalla.TURNO_JUGADOR;
        habilitarBotones(true);
    }

    private void conectarBotones() {
        ventana.btn_atacar   .addActionListener(e -> accionAtacar());
        ventana.btn_fuego    .addActionListener(e -> accionFuego());
        ventana.btn_curar    .addActionListener(e -> accionCurar());
        ventana.btn_reiniciar.addActionListener(e -> accionReiniciar());
    }
    private void iniciarBucleRender() {
        temporizadorRender = new Timer(16, e -> {
            lienzo.avanzarFotograma();
    });
        
        temporizadorRender.start();
    }
    private void accionAtacar() {
        if (!esTurnoJugador()) return;
        habilitarBotones(false);
        int danio = calcularDanio( estadoJuego.ataqueHeroe, estadoJuego.defensaEnemigo);
        estadoJuego.vidaEnemigo =Math.max(0, estadoJuego.vidaEnemigo - danio);
        estadoJuego.mensajePrincipal = "¡El héroe ataca por " + danio + " de daño!";
        estadoJuego.mensajeAccion = "";
        verificarEnemigoVencido();
    }
    private void accionFuego() {
        if (!esTurnoJugador()) return;
        if (estadoJuego.manaHeroe < EstadoJuego.COSTO_MANA_FUEGO) {
            estadoJuego.mensajePrincipal = "¡No tienes suficiente maná para Fuego!";
            estadoJuego.mensajeAccion = "(Necesita " + EstadoJuego.COSTO_MANA_FUEGO + " MN)";
            return;
        }
        
        habilitarBotones(false);
        estadoJuego.manaHeroe -= EstadoJuego.COSTO_MANA_FUEGO;
        int danio = calcularDanio( estadoJuego.ataqueHeroe * 2,estadoJuego.defensaEnemigo / 2);
        estadoJuego.vidaEnemigo = Math.max(0, estadoJuego.vidaEnemigo - danio);
        estadoJuego.mensajePrincipal = "¡El héroe lanza FUEGO por " + danio + " de daño!";
        estadoJuego.mensajeAccion = "(-" + EstadoJuego.COSTO_MANA_FUEGO + " MN)";

        verificarEnemigoVencido();
    }
 
    private void accionCurar() {
        if (!esTurnoJugador()) return;
        if (estadoJuego.manaHeroe < EstadoJuego.COSTO_MANA_CURAR) {
            estadoJuego.mensajePrincipal = "¡No tienes suficiente maná para Curar!";
            estadoJuego.mensajeAccion ="(Necesita " + EstadoJuego.COSTO_MANA_CURAR + " MN)";
            return;
        }

        habilitarBotones(false);
        estadoJuego.manaHeroe -= EstadoJuego.COSTO_MANA_CURAR;
        int recuperacion = 20 + aleatorio.nextInt(15);
        estadoJuego.vidaHeroe = Math.min(estadoJuego.vidaMaxHeroe,
        	estadoJuego.vidaHeroe + recuperacion);
        estadoJuego.mensajePrincipal ="¡El héroe se cura y recupera "+ recuperacion + " PV!";
        estadoJuego.mensajeAccion =  "(-" + EstadoJuego.COSTO_MANA_CURAR + " MN)";
        programarTurnoEnemigo();
    }

    private void accionReiniciar() {
        estadoJuego.vidaHeroe            = estadoJuego.vidaMaxHeroe;
        estadoJuego.manaHeroe            = estadoJuego.manaMaxHeroe;
        estadoJuego.vidaEnemigo          = estadoJuego.vidaMaxEnemigo;
        estadoJuego.enemigoDerrotado     = false;
        estadoJuego.mensajePrincipal     = "¡Una nueva batalla comienza!";
        estadoJuego.mensajeAccion        = "";
        estadoJuego.estado               = EstadoBatalla.TURNO_JUGADOR;
        habilitarBotones(true);
    }

   
    private void programarTurnoEnemigo() {
        temporizadorEnemigo = new Timer(900, e -> {
            temporizadorEnemigo.stop();
            ejecutarTurnoEnemigo();
        });
        temporizadorEnemigo.setRepeats(false);
        temporizadorEnemigo.start();
    }

    private void ejecutarTurnoEnemigo() {
        if (estadoJuego.enemigoDerrotado)
            return;
        int danio = calcularDanio( estadoJuego.ataqueEnemigo,estadoJuego.defensaHeroe);
        estadoJuego.vidaHeroe =Math.max(0, estadoJuego.vidaHeroe - danio);
        estadoJuego.mensajePrincipal =estadoJuego.nombreEnemigo + " ataca por " + danio  + " de daño!";
        estadoJuego.mensajeAccion = "";
        estadoJuego.estado =EstadoBatalla.TURNO_JUGADOR;
        habilitarBotones(true);
    }
   
   
    private void verificarEnemigoVencido() {
        if (estadoJuego.vidaEnemigo <= 0) {
            estadoJuego.enemigoDerrotado = true;
            estadoJuego.estado           = EstadoBatalla.VICTORIA;
            estadoJuego.mensajePrincipal = "¡" + estadoJuego.nombreEnemigo + " ha sido derrotado!";
            estadoJuego.mensajeAccion    = "¡Victoria! Presiona REINICIAR para jugar de nuevo.";
            habilitarBotones(false);
            ventana.btn_reiniciar.setEnabled(true);
        } else {
            programarTurnoEnemigo();
        }
    }

    
    private boolean esTurnoJugador() {
        return estadoJuego.estado == EstadoBatalla.TURNO_JUGADOR
            && !estadoJuego.enemigoDerrotado;
    }

    
    private int calcularDanio(int ataque, int defensa) {
        int base = Math.max(1, ataque - defensa);
        return base + aleatorio.nextInt(Math.max(1, base / 2));
    }

   
    private void habilitarBotones(boolean habilitado) {
        ventana.btn_atacar.setEnabled(habilitado);
        ventana.btn_fuego .setEnabled(habilitado);
        ventana.btn_curar .setEnabled(habilitado);
        
        ventana.btn_reiniciar.setEnabled(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        
    }
}
