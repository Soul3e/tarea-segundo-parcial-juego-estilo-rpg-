package modelo;


public class EstadoJuego {

    
    public enum EstadoBatalla {
        ESPERANDO,
        TURNO_JUGADOR,
        TURNO_ENEMIGO,
        ANIMANDO,
        VICTORIA,
        FIN_JUEGO
    }

   
    public int vidaHeroe        = 100;
    public int vidaMaxHeroe     = 100;
    public int manaHeroe        = 50;
    public int manaMaxHeroe     = 50;
    public int ataqueHeroe      = 18;
    public int defensaHeroe     = 8;

  
    public String nombreEnemigo = "Caballero Oscuro";
    public int vidaEnemigo      = 120;
    public int vidaMaxEnemigo   = 120;
    public int ataqueEnemigo    = 14;
    public int defensaEnemigo   = 5;

    
    public EstadoBatalla estado = EstadoBatalla.ESPERANDO;

  
    public String mensajePrincipal = "¡Un Caballero Oscuro aparece!";
    public String mensajeAccion    = "";
    public boolean enemigoDerrotado   = false;


    public static final int COSTO_MANA_FUEGO  = 15;
    public static final int COSTO_MANA_CURAR  = 20;
}
