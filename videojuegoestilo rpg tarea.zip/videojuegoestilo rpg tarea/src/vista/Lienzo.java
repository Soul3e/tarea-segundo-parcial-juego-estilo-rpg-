package vista;
import javax.swing.ImageIcon;
import java.awt.Image;
import modelo.EstadoJuego;
import javax.swing.*;
import java.awt.*;


public class Lienzo extends JPanel {
    private static final long serialVersionUID = 1L;
    private static final Color COLOR_CIELO         = new Color(10,  10,  40);
    private static final Color COLOR_SUELO         = new Color(25,  15,  55);
    private static final Color COLOR_VIDA_NORMAL   = new Color(80, 210, 100);
    private static final Color COLOR_VIDA_BAJA     = new Color(220, 60,  60);
    private static final Color COLOR_MANA          = new Color(80, 140, 255);
    private static final Color COLOR_DORADO        = new Color(255, 215, 80);
    private static final Color COLOR_TEXTO         = new Color(240, 235, 255);
    private static final Color COLOR_ENEMIGO       = new Color(180, 70, 220);
    private static final Color COLOR_HEROE         = new Color(100, 180, 255);
    private Image fondo;
    private EstadoJuego estadoJuego;
    private int contadorAnimacion = 0;
    
    public Lienzo(EstadoJuego estadoJuego) {
        this.estadoJuego = estadoJuego;
        if (this.estadoJuego == null) {
            this.estadoJuego = new EstadoJuego();
        }

        fondo = new ImageIcon(
                getClass().getResource("/imagen/fondo.jpg")
        ).getImage();

        setPreferredSize(new Dimension(600, 340));
    }
    public Lienzo() {
        this(new EstadoJuego());
    }
    public void avanzarFotograma() {
        contadorAnimacion++;
        repaint();
    }
    @Override
    protected void paintComponent(Graphics g0) {
        super.paintComponent(g0);
        Graphics2D g = (Graphics2D) g0;
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        int ancho = getWidth();
        int alto  = getHeight();

        dibujarFondo(g, ancho, alto);

        if (!estadoJuego.enemigoDerrotado) {
            int xEnemigo = ancho / 2 - 30 ;
            int yEnemigo = alto  / 2 - 90;
            dibujarEnemigo(g, xEnemigo, yEnemigo);
            dibujarHeroe(g,ancho - 180,alto - 220
            );
        } else {
            dibujarTextoVictoria(g, ancho, alto);
        }

        dibujarPanelEstado(g, ancho, alto);
        dibujarRegistroBatalla(g, ancho, alto);
    }
    private void dibujarFondo(Graphics2D g, int ancho, int alto) {

        if (fondo != null) {
        	g.drawImage(   fondo, 0, 0, ancho, alto,this);

        }
    }

    private void dibujarEnemigo(Graphics2D g, int x, int y) {
        float oscilacion = (float) Math.sin(contadorAnimacion * 0.06) * 4;
        int yy = (int)(y + oscilacion);

        // Sombra
        g.setColor(new Color(0, 0, 0, 60));
        g.fillOval(x - 10, yy + 105, 80, 14);

        // Cuerpo
        g.setColor(COLOR_ENEMIGO.darker());
        g.fillRoundRect(x + 10, yy + 30, 55, 70, 10, 10);

        // Cabeza y cuernos
        g.setColor(COLOR_ENEMIGO);
        g.fillOval(x + 17, yy + 5, 40, 40);
        g.fillPolygon(new int[]{x+25, x+14, x+26},new int[]{yy+10, yy-15, yy-15}, 3);
        g.fillPolygon(new int[]{x+45, x+37, x+49},new int[]{yy+10, yy-15, yy-15}, 3);

        // Ojos 
        g.setColor(new Color(255, 60, 60));
        g.fillOval(x + 22, yy + 18, 8, 8);
        g.fillOval(x + 42, yy + 18, 8, 8);

        // Espada
        g.setColor(new Color(190, 200, 220));
        g.setStroke(new BasicStroke(4, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
        g.drawLine(x + 65, yy + 20, x + 85, yy + 90);
        g.setStroke(new BasicStroke(1));
       
      
    }
    private void dibujarHeroe(Graphics2D g, int x, int y) {
        // Piernas
        g.setColor(new Color(60, 80, 160));
        g.fillRect(x + 8,  y + 70, 14, 30);
        g.fillRect(x + 28, y + 70, 14, 30);

        // Cuerpo
        g.setColor(COLOR_HEROE.darker());
        g.fillRoundRect(x + 5, y + 30, 45, 42, 8, 8);

       
        // Cabeza
        g.setColor(new Color(255, 210, 170));
        g.fillOval(x + 13, y + 5, 30, 30);

        // Cabello
        g.setColor(new Color(200, 160, 40));
        g.fillRoundRect(x + 12, y + 2, 32, 15, 8, 8);

        // Ojos
        g.setColor(new Color(40, 80, 200));
        g.fillOval(x + 18, y + 15, 6, 6);
        g.fillOval(x + 30, y + 15, 6, 6);

        // Espada
        g.setColor(new Color(220, 230, 255));
        g.setStroke(new BasicStroke(3, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
        g.drawLine(x - 10, y + 25, x + 8, y + 68);
        g.setStroke(new BasicStroke(1));
       
       
    }
    private void dibujarPanelEstado(Graphics2D g, int ancho, int alto) {
        g.setColor(new Color(5, 5, 20, 210));
        g.fillRoundRect(8, alto - 100, 260, 88, 12, 12);
        g.setColor(COLOR_DORADO);
        g.setStroke(new BasicStroke(1.5f));
        g.drawRoundRect(8, alto - 100, 260, 88, 12, 12);
        g.setStroke(new BasicStroke(1));

        g.setFont(new Font("Monospaced", Font.BOLD, 12));
        g.setColor(COLOR_TEXTO);

        // Barra de vida del héroe
        g.drawString("VD", 18, alto - 80);
        dibujarBarra(g, 48, alto - 92, 160, 14,estadoJuego.vidaHeroe, estadoJuego.vidaMaxHeroe,
        estadoJuego.vidaHeroe < 30 ? COLOR_VIDA_BAJA : COLOR_VIDA_NORMAL);
        g.setFont(new Font("Monospaced", Font.PLAIN, 11));
        g.drawString(estadoJuego.vidaHeroe + "/" + estadoJuego.vidaMaxHeroe, 215, alto - 80);

        // Barra de maná del héroe
        g.setFont(new Font("Monospaced", Font.BOLD, 12));
        g.drawString("MN", 18, alto - 58);
        dibujarBarra(g, 48, alto - 70, 160, 14,
            estadoJuego.manaHeroe, estadoJuego.manaMaxHeroe, COLOR_MANA);
        g.setFont(new Font("Monospaced", Font.PLAIN, 11));
        g.drawString(estadoJuego.manaHeroe + "/" + estadoJuego.manaMaxHeroe, 215, alto - 58);

        // Barra de vida del enemigo
        g.setFont(new Font("Monospaced", Font.BOLD, 12));
        g.setColor(COLOR_ENEMIGO.brighter());
        g.drawString(estadoJuego.nombreEnemigo, 18, alto - 33);
        dibujarBarra(g, 18, alto - 30, 230, 14,
            estadoJuego.vidaEnemigo, estadoJuego.vidaMaxEnemigo,
            estadoJuego.vidaEnemigo < 40 ? COLOR_VIDA_BAJA : new Color(200, 80, 220));
        g.setFont(new Font("Monospaced", Font.PLAIN, 11));
        g.setColor(COLOR_TEXTO);
        g.drawString(estadoJuego.vidaEnemigo + "/" + estadoJuego.vidaMaxEnemigo, 167, alto - 18);
    }
    private void dibujarBarra(Graphics2D g, int x, int y, int ancho, int alto,
                               int actual, int maximo, Color color) {
        g.setColor(new Color(30, 30, 50));
        g.fillRoundRect(x, y, ancho, alto, 6, 6);
        int relleno = (int)((double) actual / maximo * ancho);
        if (relleno > 0) {
            GradientPaint degradado = new GradientPaint(x, y, color.brighter(), x, y + alto, color.darker());
            g.setPaint(degradado);
            g.fillRoundRect(x, y, relleno, alto, 6, 6);
        }
        g.setColor(new Color(255, 255, 255, 40));
        g.drawRoundRect(x, y, ancho, alto, 6, 6);
    }
    private void dibujarRegistroBatalla(Graphics2D g, int ancho, int alto) {
        int xPanel = ancho - 310;
        g.setColor(new Color(5, 5, 20, 210));
        g.fillRoundRect(xPanel, alto - 100, 298, 88, 12, 12);
        g.setColor(COLOR_DORADO);
        g.setStroke(new BasicStroke(1.5f));
        g.drawRoundRect(xPanel, alto - 100, 298, 88, 12, 12);
        g.setStroke(new BasicStroke(1));
        g.setFont(new Font("Monospaced", Font.BOLD, 12));
        g.setColor(COLOR_DORADO);
        g.drawString("REGISTRO DE BATALLA", xPanel + 10, alto - 82);
        g.setFont(new Font("Monospaced", Font.PLAIN, 11));
        g.setColor(COLOR_TEXTO);
        dibujarTextoMultilinea(g, estadoJuego.mensajePrincipal, xPanel + 10, alto - 65, 278);
        g.setColor(new Color(150, 230, 255));
        dibujarTextoMultilinea(g, estadoJuego.mensajeAccion, xPanel + 10, alto - 35, 278);
    }
    private void dibujarTextoMultilinea(Graphics2D g, String texto, int x, int y, int anchoMax) {
        if (texto == null || texto.isEmpty()) return;
        FontMetrics fm = g.getFontMetrics();
        String[] palabras = texto.split(" ");
        StringBuilder linea = new StringBuilder();
        int yActual = y;
        for (String palabra : palabras) {
            String prueba = linea + (linea.length() > 0 ? " " : "") + palabra;
            if (fm.stringWidth(prueba) > anchoMax) {
                g.drawString(linea.toString(), x, yActual);
                yActual += fm.getHeight();
                linea = new StringBuilder(palabra);
            } else {
                linea = new StringBuilder(prueba);
            }
        }
        if (linea.length() > 0) g.drawString(linea.toString(), x, yActual);
    }
    private void dibujarTextoVictoria(Graphics2D g, int ancho, int alto) {
        float pulso = (float)(Math.sin(contadorAnimacion * 0.08) * 0.15 + 1.0);
        int tamanoFuente = (int)(28 * pulso);
        g.setFont(new Font("Monospaced", Font.BOLD, tamanoFuente));
        g.setColor(COLOR_DORADO);
        String mensaje = "¡VICTORIA!";
        FontMetrics fm = g.getFontMetrics();
        g.drawString(mensaje, (ancho - fm.stringWidth(mensaje)) / 2, alto / 2 - 30);

        g.setFont(new Font("Monospaced", Font.PLAIN, 13));
        g.setColor(COLOR_TEXTO);
        String subtitulo = "El Caballero Oscuro ha caído.";
        fm = g.getFontMetrics();
        g.drawString(subtitulo, (ancho - fm.stringWidth(subtitulo)) / 2, alto / 2);
    }
    }