package vista;

import controlador.LogicaVistaBatalla;
import modelo.EstadoJuego;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;



public class VentanaPrincipal extends JFrame {

    private static final long serialVersionUID = 1L;


    


    public Lienzo pn_lienzo;
    public JButton btn_atacar;
    public JButton btn_fuego;
    public JButton btn_curar;
    public JButton btn_reiniciar;

 
    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                EstadoJuego estadoJuego = new EstadoJuego();
                VentanaPrincipal ventana = new VentanaPrincipal(estadoJuego);
                ventana.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

 
    public VentanaPrincipal(EstadoJuego estadoJuego) {
        setTitle("Batalla");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);

        JPanel panelContenido = new JPanel();
        panelContenido.setBackground(new Color(5, 5, 20));
        panelContenido.setBorder(new EmptyBorder(8, 8, 8, 8));
        panelContenido.setLayout(null);
        setContentPane(panelContenido);

    
        pn_lienzo = new Lienzo(estadoJuego);
        pn_lienzo.setBounds(8, 6, 600, 340);
        panelContenido.add(pn_lienzo);

    
        JPanel panelBotones = new JPanel();
        panelBotones.setBackground(new Color(10, 5, 30));
        panelBotones.setBounds(8, 356, 600, 48);
        panelContenido.add(panelBotones);
        panelBotones.setLayout(null);

        btn_atacar = new JButton("ATACAR");
        btn_atacar.setBounds(10, 10, 120, 25);
        btn_atacar.setBackground(new Color(180, 40, 40));
        btn_atacar.setForeground(Color.WHITE);
        btn_atacar.setFocusPainted(false);
        btn_atacar.setFocusable(false);
        btn_atacar.setBorderPainted(false);
        btn_atacar.setOpaque(true);
        panelBotones.add(btn_atacar);

        btn_fuego = new JButton("FUEGO");
        btn_fuego.setBounds(155, 10, 120, 25);
        btn_fuego.setBackground(new Color(230, 120, 20));
        btn_fuego.setForeground(Color.WHITE);
        btn_fuego.setFocusPainted(false);
        btn_fuego.setFocusable(false);
        btn_fuego.setBorderPainted(false);
        btn_fuego.setOpaque(true);
        panelBotones.add(btn_fuego);

        btn_curar = new JButton("CURAR");
        btn_curar.setBounds(300, 10, 120, 25);
        btn_curar.setBackground(new Color(40, 160, 80));
        btn_curar.setForeground(Color.WHITE);
        btn_curar.setFocusPainted(false);
        btn_curar.setFocusable(false);
        btn_curar.setBorderPainted(false);
        btn_curar.setOpaque(true);
        panelBotones.add(btn_curar);

        btn_reiniciar = new JButton("REINICIAR");
        btn_reiniciar.setBounds(445, 10, 120, 25);
        btn_reiniciar.setBackground(new Color(70, 70, 180));
        btn_reiniciar.setForeground(Color.WHITE);
        btn_reiniciar.setFocusPainted(false);
        btn_reiniciar.setFocusable(false);
        btn_reiniciar.setBorderPainted(false);
        btn_reiniciar.setOpaque(true);
        panelBotones.add(btn_reiniciar);

        setBounds(100, 80, 632, 450);
        new LogicaVistaBatalla(this, estadoJuego);
    }
    }